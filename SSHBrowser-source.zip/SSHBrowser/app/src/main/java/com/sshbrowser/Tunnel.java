package com.sshbrowser;

import com.jcraft.jsch.ChannelDirectTCPIP;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** SSH connection + local SOCKS5 server on 127.0.0.1 (same idea as "ssh -D"). */
final class Tunnel {
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private volatile boolean closed;
    private Session session;
    private ServerSocket server;

    /** Blocking. Connects over SSH, starts the local SOCKS5 server, returns its port. */
    int start(String host, int port, String user, String pass) throws Exception {
        session = new JSch().getSession(user, host, port);
        session.setPassword(pass);
        session.setConfig("StrictHostKeyChecking", "no");
        session.setConfig("PreferredAuthentications", "password,keyboard-interactive");
        session.setServerAliveInterval(20000);
        session.connect(15000);
        server = new ServerSocket(0, 64, InetAddress.getByName("127.0.0.1"));
        pool.execute(this::acceptLoop);
        return server.getLocalPort();
    }

    boolean alive() {
        return !closed && session != null && session.isConnected();
    }

    void stop() {
        closed = true;
        try { if (server != null) server.close(); } catch (IOException ignored) { }
        if (session != null) session.disconnect();
        pool.shutdownNow();
    }

    private void acceptLoop() {
        while (!closed) {
            try {
                final Socket s = server.accept();
                pool.execute(() -> handle(s));
            } catch (Exception e) {
                break;
            }
        }
    }

    private void handle(Socket c) {
        ChannelDirectTCPIP ch = null;
        try {
            c.setTcpNoDelay(true);
            DataInputStream in = new DataInputStream(c.getInputStream());
            OutputStream out = c.getOutputStream();

            // SOCKS5 greeting: no authentication
            if (in.readUnsignedByte() != 5) return;
            in.readFully(new byte[in.readUnsignedByte()]);
            out.write(new byte[]{5, 0});
            out.flush();

            // SOCKS5 request
            in.readUnsignedByte();                 // version
            int cmd = in.readUnsignedByte();
            in.readUnsignedByte();                 // reserved
            int atyp = in.readUnsignedByte();
            String host;
            if (atyp == 1) {
                byte[] b = new byte[4];
                in.readFully(b);
                host = InetAddress.getByAddress(b).getHostAddress();
            } else if (atyp == 3) {
                byte[] b = new byte[in.readUnsignedByte()];
                in.readFully(b);
                host = new String(b, "UTF-8");
            } else if (atyp == 4) {
                byte[] b = new byte[16];
                in.readFully(b);
                host = InetAddress.getByAddress(b).getHostAddress();
            } else {
                reply(out, 8);
                return;
            }
            int port = in.readUnsignedShort();
            if (cmd != 1) {                        // only CONNECT
                reply(out, 7);
                return;
            }

            ch = (ChannelDirectTCPIP) session.openChannel("direct-tcpip");
            ch.setHost(host);
            ch.setPort(port);
            final InputStream remoteIn = ch.getInputStream();   // must be taken before connect()
            final OutputStream remoteOut = ch.getOutputStream();
            ch.connect(10000);
            reply(out, 0);

            final ChannelDirectTCPIP fch = ch;
            pool.execute(() -> pipe(remoteIn, out, c, fch));     // remote -> browser
            pipe(in, remoteOut, c, ch);                          // browser -> remote
        } catch (Exception e) {
            try { reply(c.getOutputStream(), 5); } catch (Exception ignored) { }
        } finally {
            try { c.close(); } catch (IOException ignored) { }
            if (ch != null) ch.disconnect();
        }
    }

    private static void reply(OutputStream o, int code) throws IOException {
        o.write(new byte[]{5, (byte) code, 0, 1, 0, 0, 0, 0, 0, 0});
        o.flush();
    }

    private static void pipe(InputStream in, OutputStream out, Socket s, ChannelDirectTCPIP ch) {
        byte[] buf = new byte[16384];
        try {
            int n;
            while ((n = in.read(buf)) >= 0) {
                out.write(buf, 0, n);
                out.flush();
            }
        } catch (IOException ignored) {
        } finally {
            try { s.close(); } catch (IOException ignored) { }
            ch.disconnect();
        }
    }
}
