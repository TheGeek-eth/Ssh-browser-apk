package com.sshbrowser;

import android.app.Activity;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.webkit.ProxyConfig;
import androidx.webkit.ProxyController;
import androidx.webkit.WebViewFeature;

public class MainActivity extends Activity {
    private static final int MATCH = LinearLayout.LayoutParams.MATCH_PARENT;
    private static final int WRAP = LinearLayout.LayoutParams.WRAP_CONTENT;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private WebView web;
    private EditText url, host, port, user, pass;
    private Button sshBtn, connect;
    private TextView status;
    private LinearLayout panel;
    private Tunnel tunnel;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        // --- top bar: [SSH] [address] [Go]
        LinearLayout bar = new LinearLayout(this);
        sshBtn = new Button(this);
        sshBtn.setText("SSH");
        url = new EditText(this);
        url.setHint("Search or enter address");
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        url.setImeOptions(EditorInfo.IME_ACTION_GO);
        Button go = new Button(this);
        go.setText("Go");
        bar.addView(sshBtn, new LinearLayout.LayoutParams(WRAP, WRAP));
        bar.addView(url, new LinearLayout.LayoutParams(0, WRAP, 1f));
        bar.addView(go, new LinearLayout.LayoutParams(WRAP, WRAP));

        // --- SSH panel
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(8), 0, dp(8), dp(8));
        host = field("SSH host", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        port = field("Port", InputType.TYPE_CLASS_NUMBER);
        port.setText("22");
        user = field("Username", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        pass = field("Password", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        connect = new Button(this);
        connect.setText("Connect");
        status = new TextView(this);
        status.setText("Not connected");

        LinearLayout hostRow = new LinearLayout(this);
        hostRow.addView(host, new LinearLayout.LayoutParams(0, WRAP, 1f));
        hostRow.addView(port, new LinearLayout.LayoutParams(dp(90), WRAP));
        panel.addView(hostRow, new LinearLayout.LayoutParams(MATCH, WRAP));
        panel.addView(user, new LinearLayout.LayoutParams(MATCH, WRAP));
        panel.addView(pass, new LinearLayout.LayoutParams(MATCH, WRAP));
        panel.addView(connect, new LinearLayout.LayoutParams(MATCH, WRAP));
        panel.addView(status, new LinearLayout.LayoutParams(MATCH, WRAP));

        // --- web view
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView v, String u, Bitmap icon) {
                if (!url.hasFocus()) url.setText(u);
            }
        });

        root.addView(bar, new LinearLayout.LayoutParams(MATCH, WRAP));
        root.addView(panel, new LinearLayout.LayoutParams(MATCH, WRAP));
        root.addView(web, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        setContentView(root);

        sshBtn.setOnClickListener(v -> panel.setVisibility(
                panel.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE));
        connect.setOnClickListener(v -> toggle());
        go.setOnClickListener(v -> go());
        url.setOnEditorActionListener((v, id, e) -> { go(); return true; });
    }

    private EditText field(String hint, int type) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setInputType(type);
        return e;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    // ---------------------------------------------------------------- browsing

    private void go() {
        String q = url.getText().toString().trim();
        if (q.isEmpty()) return;
        String target;
        if (q.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) target = q;
        else if (!q.contains(" ") && q.contains(".")) target = "https://" + q;
        else target = "https://duckduckgo.com/?q=" + Uri.encode(q);
        web.loadUrl(target);
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(url.getWindowToken(), 0);
        web.requestFocus();
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    // ------------------------------------------------------------------- SSH

    private void toggle() {
        if (tunnel != null) {
            disconnect();
            return;
        }
        final String h = host.getText().toString().trim();
        final String u = user.getText().toString().trim();
        final String p = pass.getText().toString();
        int parsed = -1;
        try { parsed = Integer.parseInt(port.getText().toString().trim()); }
        catch (NumberFormatException ignored) { }
        final int pt = parsed;
        if (h.isEmpty() || u.isEmpty() || pt < 1 || pt > 65535) {
            status.setText("Enter a valid host, port and username");
            return;
        }
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
            status.setText("Please update \"Android System WebView\" from Play Store");
            return;
        }
        connect.setEnabled(false);
        status.setText("Connecting...");
        final Tunnel t = new Tunnel();
        new Thread(() -> {
            try {
                final int localPort = t.start(h, pt, u, p);
                ui.post(() -> onConnected(t, localPort));
            } catch (final Exception e) {
                t.stop();
                ui.post(() -> {
                    connect.setEnabled(true);
                    status.setText("Failed: " + e.getMessage());
                });
            }
        }).start();
    }

    private void onConnected(Tunnel t, int localPort) {
        ProxyConfig cfg = new ProxyConfig.Builder()
                .addProxyRule("socks5://127.0.0.1:" + localPort)
                .build();
        ProxyController.getInstance().setProxyOverride(cfg, Runnable::run, () -> { });
        tunnel = t;
        connect.setEnabled(true);
        connect.setText("Disconnect");
        sshBtn.setText("SSH \u2713");
        status.setText("Connected - all browser traffic goes through " + host.getText());
        panel.setVisibility(View.GONE);
        watch(t);
    }

    /** Connection dropped by itself: the proxy stays set to the dead local port, so pages
     *  fail to load instead of silently going out without the tunnel. */
    private void watch(final Tunnel t) {
        new Thread(() -> {
            while (t.alive()) {
                try { Thread.sleep(2000); } catch (InterruptedException e) { return; }
            }
            ui.post(() -> {
                if (tunnel != t) return;
                tunnel = null;
                new Thread(t::stop).start();
                connect.setText("Connect");
                sshBtn.setText("SSH \u2717");
                status.setText("Connection lost - browsing is blocked until you reconnect");
                panel.setVisibility(View.VISIBLE);
            });
        }).start();
    }

    private void disconnect() {
        final Tunnel t = tunnel;
        tunnel = null;
        new Thread(t::stop).start();
        ProxyController.getInstance().clearProxyOverride(Runnable::run, () -> { });
        connect.setText("Connect");
        sshBtn.setText("SSH");
        status.setText("Not connected");
    }

    @Override
    protected void onDestroy() {
        if (tunnel != null) {
            final Tunnel t = tunnel;
            tunnel = null;
            new Thread(t::stop).start();
        }
        super.onDestroy();
    }
}
