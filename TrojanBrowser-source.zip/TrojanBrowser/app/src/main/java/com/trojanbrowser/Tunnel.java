package com.trojanbrowser;

import android.net.Uri;
import android.util.Base64;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/**
 * Trojan client (TLS or WebSocket+TLS) exposed as a local SOCKS5 server on 127.0.0.1.
 * Every SOCKS CONNECT opens its own Trojan connection to the server.
 */
final class Tunnel {
    private static final SecureRandom RNG = new SecureRandom();

    private final ExecutorService pool = Executors.newCachedThreadPool();
    private final Set<Closeable> open = ConcurrentHashMap.newKeySet();
    private volatile boolean closed;
    private ServerSocket server;

    // filled in by parse()
    private String serverHost, sni, wsHost, path;
    private int serverPort;
    private boolean ws, insecure;
    private byte[] auth;                    // hex(SHA-224(password)) as ASCII, 56 bytes
    private SSLSocketFactory factory;

    // ------------------------------------------------------------ lifecycle

    /** Blocking. Parses the link, checks the server really relays traffic, starts SOCKS5. */
    int start(String link) throws Exception {
        parse(link);
        selfTest();
        server = new ServerSocket(0, 64, InetAddress.getByName("127.0.0.1"));
        pool.execute(this::acceptLoop);
        return server.getLocalPort();
    }

    void stop() {
        closed = true;
        closeQuietly(server);
        for (Closeable c : open) closeQuietly(c);
        pool.shutdownNow();
    }

    // -------------------------------------------------------------- link

    private void parse(String link) throws Exception {
        String s = link.trim();
        if (!s.startsWith("trojan://")) throw new IOException("The link must start with trojan://");
        s = s.substring(9);
        int i = s.indexOf('#');
        if (i >= 0) s = s.substring(0, i);

        Map<String, String> q = new HashMap<>();
        i = s.indexOf('?');
        if (i >= 0) {
            for (String kv : s.substring(i + 1).split("&")) {
                int e = kv.indexOf('=');
                if (e > 0) q.put(kv.substring(0, e), Uri.decode(kv.substring(e + 1)));
            }
            s = s.substring(0, i);
        }
        if (s.endsWith("/")) s = s.substring(0, s.length() - 1);

        i = s.lastIndexOf('@');
        if (i < 0) throw new IOException("Link has no password@server part");
        String password = Uri.decode(s.substring(0, i));
        String hp = s.substring(i + 1);
        if (hp.startsWith("[")) {                       // [IPv6]:port
            int end = hp.indexOf(']');
            serverHost = hp.substring(1, end);
            serverPort = hp.length() > end + 2 ? Integer.parseInt(hp.substring(end + 2)) : 443;
        } else {
            int colon = hp.lastIndexOf(':');
            if (colon > 0) {
                serverHost = hp.substring(0, colon);
                serverPort = Integer.parseInt(hp.substring(colon + 1));
            } else {
                serverHost = hp;
                serverPort = 443;
            }
        }

        String type = q.containsKey("type") ? q.get("type") : "tcp";
        String security = q.containsKey("security") ? q.get("security") : "tls";
        if (!security.equals("tls")) throw new IOException("Only security=tls is supported");
        if (type.equals("ws")) ws = true;
        else if (!type.equals("tcp")) throw new IOException("Unsupported transport: " + type + " (only tcp and ws)");

        sni = first(q.get("sni"), q.get("peer"), q.get("host"), serverHost);
        wsHost = first(q.get("host"), sni);
        path = first(q.get("path"), "/");
        if (!path.startsWith("/")) path = "/" + path;
        String ai = first(q.get("allowInsecure"), q.get("insecure"), "0");
        insecure = ai.equals("1") || ai.equals("true");

        byte[] h = MessageDigest.getInstance("SHA-224").digest(password.getBytes("UTF-8"));
        StringBuilder hex = new StringBuilder();
        for (byte b : h) hex.append(String.format("%02x", b & 0xff));
        auth = hex.toString().getBytes("US-ASCII");

        factory = insecure ? trustAllFactory() : (SSLSocketFactory) SSLSocketFactory.getDefault();
    }

    private static String first(String... v) {
        for (String x : v) if (x != null && !x.isEmpty()) return x;
        return "";
    }

    private static SSLSocketFactory trustAllFactory() throws Exception {
        TrustManager[] tm = {new X509TrustManager() {
            public void checkClientTrusted(X509Certificate[] c, String a) { }
            public void checkServerTrusted(X509Certificate[] c, String a) { }
            public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
        }};
        SSLContext ctx = SSLContext.getInstance("TLS");
        ctx.init(null, tm, null);
        return ctx.getSocketFactory();
    }

    // -------------------------------------------------------- self test

    /** Opens one real Trojan connection and fetches a tiny page, so a wrong password/path shows up now. */
    private void selfTest() throws IOException {
        byte[] name = "cp.cloudflare.com".getBytes("US-ASCII");
        byte[] addr = new byte[name.length + 1];
        addr[0] = (byte) name.length;
        System.arraycopy(name, 0, addr, 1, name.length);
        Upstream u = connect(3, addr, 80);
        try {
            u.sock.setSoTimeout(10000);
            byte[] rq = ("GET /generate_204 HTTP/1.1\r\nHost: cp.cloudflare.com\r\n"
                    + "Connection: close\r\n\r\n").getBytes("US-ASCII");
            u.write(rq, 0, rq.length);
            byte[] b = new byte[16];
            int got = 0;
            while (got < 5) {
                int n = u.read(b, got, b.length - got);
                if (n < 0) break;
                got += n;
            }
            if (got < 5 || !new String(b, 0, got, "US-ASCII").startsWith("HTTP/")) {
                throw new IOException("Server reached, but it did not relay traffic - check password and path");
            }
        } finally {
            u.close();
        }
    }

    // ---------------------------------------------------------- upstream

    private Upstream connect(int atyp, byte[] addr, int port) throws IOException {
        Socket raw = new Socket();
        SSLSocket ssl = null;
        try {
            raw.setTcpNoDelay(true);
            raw.connect(new InetSocketAddress(serverHost, serverPort), 10000);
            raw.setSoTimeout(15000);
            ssl = (SSLSocket) factory.createSocket(raw, sni, serverPort, true);
            ssl.startHandshake();
            if (!insecure) {
                HostnameVerifier v = HttpsURLConnection.getDefaultHostnameVerifier();
                if (!v.verify(sni, ssl.getSession())) {
                    throw new IOException("Server certificate does not match " + sni);
                }
            }
            Upstream u = new Upstream(ssl);
            open.add(u);
            if (ws) u.handshake();
            u.sendHeader(atyp, addr, port);
            ssl.setSoTimeout(0);
            return u;
        } catch (IOException | RuntimeException e) {
            closeQuietly(ssl != null ? ssl : raw);
            throw e;
        }
    }

    private final class Upstream implements Closeable {
        final SSLSocket sock;
        final BufferedInputStream in;
        final OutputStream out;
        private final Object wlock = new Object();
        private long remaining;             // bytes left in the current WebSocket data frame

        Upstream(SSLSocket s) throws IOException {
            sock = s;
            in = new BufferedInputStream(s.getInputStream(), 16384);
            out = s.getOutputStream();
        }

        @Override
        public void close() {
            open.remove(this);
            closeQuietly(sock);
        }

        // ---- WebSocket upgrade
        void handshake() throws IOException {
            byte[] kb = new byte[16];
            RNG.nextBytes(kb);
            String req = "GET " + path + " HTTP/1.1\r\n"
                    + "Host: " + wsHost + "\r\n"
                    + "User-Agent: Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) "
                    + "Chrome/124.0.0.0 Mobile Safari/537.36\r\n"
                    + "Upgrade: websocket\r\n"
                    + "Connection: Upgrade\r\n"
                    + "Sec-WebSocket-Key: " + Base64.encodeToString(kb, Base64.NO_WRAP) + "\r\n"
                    + "Sec-WebSocket-Version: 13\r\n\r\n";
            out.write(req.getBytes("ISO-8859-1"));
            out.flush();

            StringBuilder sb = new StringBuilder();
            while (true) {
                int c = in.read();
                if (c < 0) throw new IOException("Server closed the connection during WebSocket upgrade");
                sb.append((char) c);
                int n = sb.length();
                if (n >= 4 && sb.charAt(n - 1) == '\n' && sb.charAt(n - 2) == '\r'
                        && sb.charAt(n - 3) == '\n' && sb.charAt(n - 4) == '\r') break;
                if (n > 8192) throw new IOException("Bad WebSocket upgrade response");
            }
            String status = sb.substring(0, sb.indexOf("\r\n"));
            if (!status.contains(" 101")) throw new IOException("WebSocket upgrade refused: " + status);
        }

        // ---- Trojan request header
        void sendHeader(int atyp, byte[] addr, int port) throws IOException {
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            b.write(auth, 0, auth.length);
            b.write(13);
            b.write(10);
            b.write(1);                     // CONNECT
            b.write(atyp);
            b.write(addr, 0, addr.length);
            b.write(port >> 8);
            b.write(port);
            b.write(13);
            b.write(10);
            byte[] h = b.toByteArray();
            write(h, 0, h.length);
        }

        // ---- data
        void write(byte[] p, int off, int len) throws IOException {
            if (!ws) {
                out.write(p, off, len);
                out.flush();
                return;
            }
            while (len > 0) {
                int n = Math.min(len, 16384);
                sendFrame(2, p, off, n);
                off += n;
                len -= n;
            }
        }

        int read(byte[] buf, int off, int len) throws IOException {
            if (!ws) return in.read(buf, off, len);
            while (remaining == 0) {
                int b0 = in.read();
                if (b0 < 0) return -1;
                int b1 = in.read();
                if (b1 < 0) return -1;
                int op = b0 & 0x0f;
                long n = b1 & 0x7f;
                if (n == 126) n = ((long) rd() << 8) | rd();
                else if (n == 127) {
                    n = 0;
                    for (int k = 0; k < 8; k++) n = (n << 8) | rd();
                }
                if ((b1 & 0x80) != 0) skipFully(4);     // servers don't mask; ignore a key if present
                if (op == 8) return -1;                  // close
                if (op == 9) {                           // ping -> pong
                    byte[] p = new byte[(int) n];
                    readFully(p);
                    sendFrame(10, p, 0, p.length);
                    continue;
                }
                if (op == 10) {                          // pong
                    skipFully(n);
                    continue;
                }
                remaining = n;                           // text / binary / continuation
            }
            int r = in.read(buf, off, (int) Math.min(len, remaining));
            if (r < 0) return -1;
            remaining -= r;
            return r;
        }

        private void sendFrame(int opcode, byte[] p, int off, int len) throws IOException {
            synchronized (wlock) {
                int hl = len < 126 ? 6 : 8;              // len < 65536 always (callers chunk to 16 KB)
                byte[] f = new byte[hl + len];
                f[0] = (byte) (0x80 | opcode);
                int i = 1;
                if (len < 126) {
                    f[i++] = (byte) (0x80 | len);
                } else {
                    f[i++] = (byte) (0x80 | 126);
                    f[i++] = (byte) (len >> 8);
                    f[i++] = (byte) len;
                }
                byte[] mask = new byte[4];
                RNG.nextBytes(mask);
                System.arraycopy(mask, 0, f, i, 4);
                i += 4;
                for (int k = 0; k < len; k++) f[i + k] = (byte) (p[off + k] ^ mask[k & 3]);
                out.write(f);
                out.flush();
            }
        }

        private int rd() throws IOException {
            int c = in.read();
            if (c < 0) throw new IOException("Connection closed");
            return c;
        }

        private void readFully(byte[] b) throws IOException {
            int o = 0;
            while (o < b.length) {
                int r = in.read(b, o, b.length - o);
                if (r < 0) throw new IOException("Connection closed");
                o += r;
            }
        }

        private void skipFully(long n) throws IOException {
            while (n > 0) {
                long s = in.skip(n);
                if (s <= 0) {
                    rd();
                    s = 1;
                }
                n -= s;
            }
        }
    }

    // ------------------------------------------------------ local SOCKS5

    private void acceptLoop() {
        while (!closed) {
            try {
                final Socket s = server.accept();
                pool.execute(() -> handle(s));
            } catch (Exception e) {
                break;
            }
        }
    }

    private void handle(Socket c) {
        Upstream up = null;
        open.add(c);
        try {
            c.setTcpNoDelay(true);
            DataInputStream in = new DataInputStream(c.getInputStream());
            OutputStream out = c.getOutputStream();

            // greeting: no authentication
            if (in.readUnsignedByte() != 5) return;
            in.readFully(new byte[in.readUnsignedByte()]);
            out.write(new byte[]{5, 0});
            out.flush();

            // request
            in.readUnsignedByte();
            int cmd = in.readUnsignedByte();
            in.readUnsignedByte();
            int atyp = in.readUnsignedByte();
            byte[] addr;                    // same layout Trojan uses (domain keeps its length byte)
            if (atyp == 1) {
                addr = new byte[4];
                in.readFully(addr);
            } else if (atyp == 3) {
                int l = in.readUnsignedByte();
                addr = new byte[l + 1];
                addr[0] = (byte) l;
                in.readFully(addr, 1, l);
            } else if (atyp == 4) {
                addr = new byte[16];
                in.readFully(addr);
            } else {
                reply(out, 8);
                return;
            }
            int port = in.readUnsignedShort();
            if (cmd != 1) {                 // CONNECT only
                reply(out, 7);
                return;
            }

            up = connect(atyp, addr, port);
            reply(out, 0);
            final Upstream fu = up;
            pool.execute(() -> pumpDown(fu, out, c));   // server -> browser
            pumpUp(in, fu);                              // browser -> server
        } catch (Exception e) {
            try { reply(c.getOutputStream(), 5); } catch (Exception ignored) { }
        } finally {
            open.remove(c);
            closeQuietly(c);
            if (up != null) up.close();
        }
    }

    private void pumpUp(InputStream in, Upstream up) {
        byte[] buf = new byte[16384];
        try {
            int n;
            while ((n = in.read(buf)) >= 0) up.write(buf, 0, n);
        } catch (IOException ignored) {
        }
    }

    private void pumpDown(Upstream up, OutputStream out, Socket c) {
        byte[] buf = new byte[16384];
        try {
            int n;
            while ((n = up.read(buf, 0, buf.length)) >= 0) {
                out.write(buf, 0, n);
                out.flush();
            }
        } catch (IOException ignored) {
        } finally {
            closeQuietly(c);
            up.close();
        }
    }

    private static void reply(OutputStream o, int code) throws IOException {
        o.write(new byte[]{5, (byte) code, 0, 1, 0, 0, 0, 0, 0, 0});
        o.flush();
    }

    private static void closeQuietly(Closeable c) {
        try { if (c != null) c.close(); } catch (IOException ignored) { }
    }
}
