package com.trojanbrowser;

import android.app.Activity;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.webkit.ProxyConfig;
import androidx.webkit.ProxyController;
import androidx.webkit.WebViewFeature;

public class MainActivity extends Activity {
    private static final int MATCH = LinearLayout.LayoutParams.MATCH_PARENT;
    private static final int WRAP = LinearLayout.LayoutParams.WRAP_CONTENT;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private WebView web;
    private EditText url, link;
    private Button proxyBtn, connect;
    private TextView status;
    private LinearLayout panel;
    private Tunnel tunnel;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        // --- top bar: [Trojan] [address] [Go]
        LinearLayout bar = new LinearLayout(this);
        proxyBtn = new Button(this);
        proxyBtn.setText("Trojan");
        url = new EditText(this);
        url.setHint("Search or enter address");
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        url.setImeOptions(EditorInfo.IME_ACTION_GO);
        Button go = new Button(this);
        go.setText("Go");
        bar.addView(proxyBtn, new LinearLayout.LayoutParams(WRAP, WRAP));
        bar.addView(url, new LinearLayout.LayoutParams(0, WRAP, 1f));
        bar.addView(go, new LinearLayout.LayoutParams(WRAP, WRAP));

        // --- proxy panel: one field for the trojan:// link
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(8), 0, dp(8), dp(8));
        link = new EditText(this);
        link.setHint("Paste your trojan:// link");
        link.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        connect = new Button(this);
        connect.setText("Connect");
        status = new TextView(this);
        status.setText("Not connected");
        panel.addView(link, new LinearLayout.LayoutParams(MATCH, WRAP));
        panel.addView(connect, new LinearLayout.LayoutParams(MATCH, WRAP));
        panel.addView(status, new LinearLayout.LayoutParams(MATCH, WRAP));

        // --- web view
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView v, String u, Bitmap icon) {
                if (!url.hasFocus()) url.setText(u);
            }
        });

        root.addView(bar, new LinearLayout.LayoutParams(MATCH, WRAP));
        root.addView(panel, new LinearLayout.LayoutParams(MATCH, WRAP));
        root.addView(web, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        setContentView(root);

        proxyBtn.setOnClickListener(v -> panel.setVisibility(
                panel.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE));
        connect.setOnClickListener(v -> toggle());
        go.setOnClickListener(v -> go());
        url.setOnEditorActionListener((v, id, e) -> { go(); return true; });
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    // ---------------------------------------------------------------- browsing

    private void go() {
        String q = url.getText().toString().trim();
        if (q.isEmpty()) return;
        String target;
        if (q.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) target = q;
        else if (!q.contains(" ") && q.contains(".")) target = "https://" + q;
        else target = "https://duckduckgo.com/?q=" + Uri.encode(q);
        web.loadUrl(target);
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(url.getWindowToken(), 0);
        web.requestFocus();
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    // ------------------------------------------------------------------ proxy

    private void toggle() {
        if (tunnel != null) {
            disconnect();
            return;
        }
        final String l = link.getText().toString().trim();
        if (l.isEmpty()) {
            status.setText("Paste your trojan:// link first");
            return;
        }
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
            status.setText("Please update \"Android System WebView\" from Play Store");
            return;
        }
        connect.setEnabled(false);
        status.setText("Connecting...");
        final Tunnel t = new Tunnel();
        new Thread(() -> {
            try {
                final int localPort = t.start(l);
                ui.post(() -> onConnected(t, localPort));
            } catch (final Exception e) {
                t.stop();
                final String msg = e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName();
                ui.post(() -> {
                    connect.setEnabled(true);
                    status.setText("Failed: " + msg);
                });
            }
        }).start();
    }

    private void onConnected(Tunnel t, int localPort) {
        ProxyConfig cfg = new ProxyConfig.Builder()
                .addProxyRule("socks5://127.0.0.1:" + localPort)
                .build();
        ProxyController.getInstance().setProxyOverride(cfg, Runnable::run, () -> { });
        tunnel = t;
        connect.setEnabled(true);
        connect.setText("Disconnect");
        proxyBtn.setText("Trojan \u2713");
        status.setText("Connected - all browser traffic goes through the Trojan server");
        panel.setVisibility(View.GONE);
    }

    private void disconnect() {
        final Tunnel t = tunnel;
        tunnel = null;
        new Thread(t::stop).start();
        ProxyController.getInstance().clearProxyOverride(Runnable::run, () -> { });
        connect.setText("Connect");
        proxyBtn.setText("Trojan");
        status.setText("Not connected");
    }

    @Override
    protected void onDestroy() {
        if (tunnel != null) {
            final Tunnel t = tunnel;
            tunnel = null;
            new Thread(t::stop).start();
        }
        super.onDestroy();
    }
}
